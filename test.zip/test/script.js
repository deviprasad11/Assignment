function red(){
    document.getElementById("txt").style.color="red";
}
document.getElementById("btn").addEventListener("click", red)

function green(){
    document.getElementById("txt").style.color="green";
}
document.getElementById("btng").addEventListener("click", green);

function blue(){
    document.getElementById("txt").style.color="blue";
}
document.getElementById("btnb").addEventListener("click", blue);

function _20(){
    document.getElementById("txt").style.fontSize="20px";
}
document.getElementById("fnt1").addEventListener("click", _20);

function _30(){
    document.getElementById("txt").style.fontSize="30px";
}
document.getElementById("fnt2").addEventListener("click", _30);

function _40(){
    document.getElementById("txt").style.fontSize="40px";
}
document.getElementById("fnt3").addEventListener("click", _40);


function family1(){
    document.getElementById("txt").style.fontFamily="arial";
}
document.getElementById("faml1").addEventListener("click", family1);

function family2(){
    document.getElementById("txt").style.fontFamily="helvetica";
}
document.getElementById("faml2").addEventListener("click", family2);

function family3(){
    document.getElementById("txt").style.fontFamily="cursive";
}
document.getElementById("faml3").addEventListener("click", family3);

